require "administrate/field/base"

class DateField < Administrate::Field::Base
  def to_s
    data
  end
end
